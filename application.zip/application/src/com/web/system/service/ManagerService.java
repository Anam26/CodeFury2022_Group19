package com.web.system.service;

import java.util.List;

import com.web.system.dao.UserDao;
import com.web.system.model.MeetingDataForUser;

/**
 * 
 * @author The Xceptionals
 * Service class for Manager
 *
 */
public class ManagerService {
	private UserDao userDao=new UserDao();
	
	public List<MeetingDataForUser> meetings(int userid){
		
		try {
			return userDao.getMeetings(userid);
		}
		catch(RuntimeException re) {
			throw re;
		}
		
	}
	


}
