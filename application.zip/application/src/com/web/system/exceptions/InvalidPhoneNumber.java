/**
 * 
 */
package com.web.system.exceptions;

import java.util.logging.Logger;

/**
 * @author The Xceptionals
 *
 */
public class InvalidPhoneNumber extends Exception {
		
	public InvalidPhoneNumber() {
		System.out.println("Invalid Phone Number in the Json Field");
	}
	
}
