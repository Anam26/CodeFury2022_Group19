/**
 * 
 */
package com.web.system.exceptions;

import java.util.logging.Logger;

/**
 * @author The Xceptionals
 *
 */
public class InvalidUser extends Exception {
		
	public InvalidUser() {
		System.out.println("Invalid User in the Json Field");
	}
	
}
