/**
 * 
 */
package com.web.system.exceptions;

import java.util.logging.Logger;

/**
 * @author The Xceptionals
 *
 */
public class InvalidEmail extends Exception {
		
	public InvalidEmail() {
		System.out.println("Invalid Email in the Json Field");
	}
	
}
