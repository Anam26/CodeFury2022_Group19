/**
 * 
 */
package com.web.system.exceptions;

import java.util.logging.Logger;

/**
 * @author The Xceptionals
*
 */
public class InvalidRole extends Exception {
		
	public InvalidRole() {
		System.out.println("Invalid Role in the Json Field");
	}
	
}
